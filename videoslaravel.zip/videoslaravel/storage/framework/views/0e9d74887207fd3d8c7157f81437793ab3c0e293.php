<?php if(count($videos) >= 1): ?>
    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="video-item col-md-8 float-ce card">
            <div class="card-body">
                <div class="data">
                    <h5><a href=""><?php echo e($video->title); ?></a></h5>
                </div>
                <!-- Imagen del video-->
                
                <div class="video-image-thumb col-md-4 float-left">
                    <div class="col-md-6 offset-md-0">
                        <img class="video-image-mask" src="<?php echo e(!empty($video->image)?route('imageVideo',$video->image):asset('img/default.png')); ?>">
                    </div>
                </div>
                
                <div>
                    <p>Propietario: <a href="<?php echo e(route('channel',$video->user->id)); ?>"><?php echo e($video->user->name); ?></a></p>
                    <p>Apodo: <?php echo e($video->user->surname); ?></p>
                </div>

                <div>
                    <a href="<?php echo e(route('videoDetaill',$video->id)); ?>" class="btn btn-success">Ver</a>
                    <?php if(Auth::check() && Auth::user()->id == $video->user->id): ?>
                        <a href="<?php echo e(route('videoEditForm',$video->id )); ?>" class="btn btn-warning">Editar</a>
                        <a href="javascript:void(0)" role="button" class="btn btn-danger" data-toggle="modal" data-target="#victorModal<?php echo e($video->id); ?>">Eliminar</a>
                        <?php echo $__env->make('video.modal.popup_deleteVideo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/udemy/victor_robles/laravel_angular/videoslaravel/resources/views/video/video.blade.php ENDPATH**/ ?>