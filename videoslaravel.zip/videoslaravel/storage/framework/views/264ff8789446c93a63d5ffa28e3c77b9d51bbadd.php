<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <h2 class="col-12">Crear un nuevo video</h2>
            <hr>
            <form action="<?php echo e(route('saveVideo')); ?>" method="POST" enctype="multipart/form-data" class="col-lg-7">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="title">Titulo</label>
                    <input type="text" class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="title" name="title" placeholder="Titulo del video" value="<?php echo e(old('title')); ?>">
                    <?php echo $errors->first('title','<span class="error">:message</span>'); ?>

                </div>
                <div class="form-group">
                    <label for="description">Descipcion</label>
                    <textarea class="form-control <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="description" name="description" placeholder="Descripcion del video"><?php echo e(old('description')); ?></textarea>
                    <?php echo $errors->first('description','<span class=error>:message</span>'); ?>

                </div>
                <div class="form-group">
                    <label for="image">Miniatura</label>
                    <input type="file" class="form-control <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="image" name="image">
                    <?php echo $errors->first('image','<span class=error>:message</span>'); ?>

                </div>
                <div class="form-group">
                    <label for="video">Archivo de video</label>
                    <input type="file" class="form-control <?php if ($errors->has('video')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('video'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="video" name="video">
                    <?php echo $errors->first('video','<span class=error>:message</span>'); ?>

                </div>
                <button type="submit" class="btn btn-success">Crear Video</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/udemy/victor_robles/laravel_angular/videoslaravel/resources/views/video/createVideo.blade.php ENDPATH**/ ?>