<hr>
<?php if(Auth::check()): ?> <!-- Si estas logueado te muestro los comentarios -->
    <h4>Ingresa comentario:</h4>
    <form class="col-md-4" action="<?php echo e(route('comment')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="video_id" value="<?php echo e($video->id); ?>" required>
        <p>
            <textarea class="form-control" name="comentario" required></textarea>
            <?php echo $errors->first('comentario','<span class=error>:message</span>'); ?>

        </p>
        <input type="submit" value="Comentar" class="btn btn-success">
    </form>
<?php endif; ?>
<div class="clearfix"></div>
<hr>
<?php if(isset($video->comments)): ?>
    <div class="comments-list">
        <?php $__currentLoopData = $video->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="comment-item col-md-12 float-left">
                <div class="card comments-data">
                    <div class="card-header">
                        <div class="card-title">
                            Creado por: <strong><?php echo e($comment->user->surname); ?></strong> <?php echo e(\App\Helpers\FormatTime::LongTimeFilter($comment->created_at)); ?>

                        </div>
                    </div>
                    <div class="card-body">
                        <?php echo e($comment->body); ?>

                        <!-- con Auth::user()->id es el usaurio loggeado actualemnte-->
                            <!-- con $comments->user_id es el id del usuario en la tabla commentarios-->
                            <!-- primero verificamos si el usuario logueado es igual al id del usuario del comentario podra borrar el comentario-->
                            <!-- verificamos si el id del usuario loggueado es el dueño del video puede borrar el comentario -->
                        <?php if( Auth::check() && (Auth::user()->id == $comment->user_id || Auth::user()->id == $video->user->id) ): ?>
                            <!-- Botón en HTML (lanza el modal en Bootstrap) -->
                                <div class="float-right">
                                    <a href="javascript:void(0)" role="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#victorModal<?php echo e($comment->id); ?>">Eliminar</a>
                                    <?php echo $__env->make('video.modal.popup_deleteMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?><?php /**PATH /var/www/html/udemy/victor_robles/laravel_angular/videoslaravel/resources/views/video/comments.blade.php ENDPATH**/ ?>