<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="container">
            <?php if( !empty(session('info')) || !empty(session('error')) ): ?>
                <?php
                    $info = session('info');
                    $error = session('error');
                ?>

                <?php if(!empty($info)): ?>
                    <?php
                        $mensaje = $info ;
                        $tipoClas = ' alert-success ';
                    ?>
                <?php else: ?>
                    <?php
                        $mensaje = $error;
                        $tipoClas = ' alert-danger ';
                    ?>
                <?php endif; ?>
                <div class="alert <?php echo e($tipoClas); ?>">
                    <?php echo e($mensaje); ?>

                </div>
            <?php endif; ?>
            <div class="videos-list">
                <?php echo $__env->make('video.video', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <?php echo e($videos->links()); ?>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/udemy/victor_robles/laravel_angular/videoslaravel/resources/views/home.blade.php ENDPATH**/ ?>