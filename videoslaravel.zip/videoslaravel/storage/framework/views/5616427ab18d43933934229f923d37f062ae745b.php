<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <h2><?php echo e($video->title); ?></h2>
        <hr>
        <div class="col-md-8">
            <!-- Video-->
            <!-- Descripccion-->
            <!-- Commentarios-->
        </div>
    </div>
    <?php $__env->startSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/udemy/victor_robles/laravel_angular/videoslaravel/resources/views/video/videodatail.blade.php ENDPATH**/ ?>