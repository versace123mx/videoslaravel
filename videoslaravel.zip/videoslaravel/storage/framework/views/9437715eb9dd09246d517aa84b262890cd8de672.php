<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 offset-md-1">
                <h2><?php echo e($video->title); ?></h2>
                <?php if( !empty(session('info')) || !empty(session('error')) ): ?>
                    <?php
                        $info = session('info');
                        $error = session('error');
                    ?>

                    <?php if(!empty($info)): ?>
                        <?php
                            $mensaje = $info ;
                            $tipoClas = ' alert-success ';
                        ?>
                        <?php else: ?>
                        <?php
                            $mensaje = $error;
                            $tipoClas = ' alert-danger ';
                        ?>
                        <?php endif; ?>
                    <div class="alert <?php echo e($tipoClas); ?>">
                        <?php echo e($mensaje); ?>

                    </div>
                    <?php endif; ?>
                <div class="col-md-8">

                    <!-- Video-->
                    <?php if(!empty($video->video_path)): ?>
                        <video width="640" height="480" controls id="<?php echo e($video->id); ?>">
                            <source src="<?php echo e(route('showvideo',$video->video_path)); ?>">
                            Tu navegador no soporta HTML5
                        </video>
                    <?php else: ?>
                        <p>Lo sentimos no existe video</p>
                <?php endif; ?>
                <!-- Descripccion-->
                    <div class="card video-data">
                        <div class="card-header">
                            <div class="card-title">
                                Subido por: <strong><?php echo e($video->user->surname); ?></strong> <?php echo e($video->fecha_publicacion); ?>

                            </div>
                        </div>
                        <div class="card-body">
                            <?php echo e($video->description); ?>

                        </div>
                    </div>
                    <!-- Commentarios-->
                        <?php echo $__env->make('video.comments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="card-body">
                <a class="btn btn-primary" href="<?php echo e(route('home')); ?>"> Regresar al listado</a>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/udemy/victor_robles/laravel_angular/videoslaravel/resources/views/video/videodetaill.blade.php ENDPATH**/ ?>